"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck: generated
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const url = __importStar(require("node:url"));
const internal = __importStar(require("../lib/swisseph_wasm.internal.js"));
const swisseph_wasm_internal_js_1 = require("../lib/swisseph_wasm.internal.js");
const currDir = path.dirname(url.fileURLToPath(globalThis[Symbol.for("import-meta-ponyfill-commonjs")](require, module).url));
const wasmPath = path.join(currDir, "../lib/swisseph_wasm.wasm");
const wasmModule = new WebAssembly.Module(fs.readFileSync(wasmPath));
const wasmInstance = new WebAssembly.Instance(wasmModule, {
    "./swisseph_wasm.internal.js": internal,
});
const wasm = wasmInstance.exports;
(0, swisseph_wasm_internal_js_1.__wbg_set_wasm)(wasm);
if (wasm.__wbindgen_start) {
    wasm.__wbindgen_start();
}
__exportStar(require("../lib/swisseph_wasm.internal.js"), exports);
