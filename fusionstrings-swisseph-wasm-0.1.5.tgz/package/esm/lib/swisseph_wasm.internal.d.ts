export function __wbg_set_wasm(val: any): void;
/**
 * @param {number} tjd_ut
 * @param {number} ipl
 * @param {number} iflag
 * @returns {any}
 */
export function swe_calc_ut(tjd_ut: number, ipl: number, iflag: number): any;
/**
 * @param {string} star
 * @param {number} tjd_ut
 * @param {number} iflag
 * @returns {any}
 */
export function swe_fixstar_ut(star: string, tjd_ut: number, iflag: number): any;
/**
 * @param {number} tjd_ut
 * @returns {number}
 */
export function swe_get_ayanamsa_ut(tjd_ut: number): number;
/**
 * @param {number} ipl
 * @returns {string}
 */
export function swe_get_planet_name(ipl: number): string;
/**
 * @param {number} year
 * @param {number} month
 * @param {number} day
 * @param {number} hour
 * @param {number} gregflag
 * @returns {number}
 */
export function swe_julday(year: number, month: number, day: number, hour: number, gregflag: number): number;
/**
 * @param {number} tjd_ut
 * @param {number} ipl
 * @param {number} iflag
 * @returns {any}
 */
export function swe_pheno_ut(tjd_ut: number, ipl: number, iflag: number): any;
/**
 * @param {number} tjd
 * @param {number} gregflag
 * @returns {any}
 */
export function swe_revjul(tjd: number, gregflag: number): any;
/**
 * @param {number} sid_mode
 * @param {number} t0
 * @param {number} ayan_t0
 */
export function swe_set_sid_mode(sid_mode: number, t0: number, ayan_t0: number): void;
/**
 * @param {number} geolon
 * @param {number} geolat
 * @param {number} geoalt
 */
export function swe_set_topo(geolon: number, geolat: number, geoalt: number): void;
/**
 * @param {number} tjd_ut
 * @returns {number}
 */
export function swe_sidtime(tjd_ut: number): number;
export function __wbg___wbindgen_debug_string_adfb662ae34724b6(arg0: any, arg1: any): void;
export function __wbg___wbindgen_throw_dd24417ed36fc46e(arg0: any, arg1: any): void;
export function __wbg_new_1ba21ce319a06297(): Object;
export function __wbg_set_781438a03c0c3c81(...args: any[]): any;
export function __wbindgen_cast_2241b6af4c4b2941(arg0: any, arg1: any): string;
export function __wbindgen_cast_d6cd19b81560fd6e(arg0: any): any;
export function __wbindgen_init_externref_table(): void;
//# sourceMappingURL=swisseph_wasm.internal.d.ts.map