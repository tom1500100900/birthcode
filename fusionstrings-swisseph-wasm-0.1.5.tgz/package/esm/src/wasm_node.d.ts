export * from "../lib/swisseph_wasm.internal.js";
//# sourceMappingURL=wasm_node.d.ts.map