// @generated file from wasmbuild -- do not edit
// deno-lint-ignore-file
// deno-fmt-ignore-file

export function swe_calc_ut(tjd_ut: number, ipl: number, iflag: number): any;

export function swe_fixstar_ut(
  star: string,
  tjd_ut: number,
  iflag: number,
): any;

export function swe_get_ayanamsa_ut(tjd_ut: number): number;

export function swe_get_planet_name(ipl: number): string;

export function swe_julday(
  year: number,
  month: number,
  day: number,
  hour: number,
  gregflag: number,
): number;

export function swe_pheno_ut(tjd_ut: number, ipl: number, iflag: number): any;

export function swe_revjul(tjd: number, gregflag: number): any;

export function swe_set_sid_mode(
  sid_mode: number,
  t0: number,
  ayan_t0: number,
): void;

export function swe_set_topo(
  geolon: number,
  geolat: number,
  geoalt: number,
): void;

export function swe_sidtime(tjd_ut: number): number;
